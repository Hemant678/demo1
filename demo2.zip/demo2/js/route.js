app.config(function($stateProvider,$compileProvider, $urlRouterProvider) {
        $stateProvider
         .state('home', {
            url: '/home',
            templateUrl: base_url+"Home/product_list",
            data : { pageTitle: 'Product List' }
          })

         .state('editproduct', {
            url: '/editproduct',
            templateUrl: base_url+"Home/edit_product",
            data : { pageTitle: 'Edit Product' }
          })
        
        $urlRouterProvider.otherwise('/home');
}).run(function($rootScope, $state) {
      $rootScope.$state = $state;
    });
