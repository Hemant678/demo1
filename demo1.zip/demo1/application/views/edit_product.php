<style>
/* Full-width input fields */
.frm_input {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    border: 1px solid #ccc;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 60%;
}

body {
  font-size: 11px;
}
.container {
    width: 735px;
}

/* Extra styles for the cancel button */
.cancelbtn {
    padding: 14px 20px;
    background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn,.signupbtn {
    float: left;
    width: 50%;
}

/* Add padding to container elements */
.container {
    padding: 16px;
}

</style>
<div class="container" style="min-height:500px;">
<h1>Edit Product</h1>
 <form>
  <div class="container">
    <label><b>Product Name</b></label>
    <input type="text" placeholder="Enter Email" class="frm_input" id="productName" ng-model='productName' required>
    <label><b>Product Quentity</b></label>
    <input type="text" placeholder="Enter Email" class="frm_input" name="productQuentity" ng-model='productQuentity' required>
    <label><b>Product Category</b></label>
    <select name="productCategory" class="frm_input" ng-model='productCategory'>
        <option value="Mobiles & Accessories">Mobiles & Accessories</option>
        <option value="Televisions">Televisions</option>
    </select>
    <label><b>Product Sub Category</b></label>
    <select class="frm_input" name="productSubCategory" ng-model='productSubCategory'>
        <option value="SAMSUNG">SAMSUNG</option>
        <option value="LG">LG</option>
    </select>
    <div class="clearfix">
      <button type="submit" class="signupbtn" ng-click="update_product(p_id)">Update</button>
      <button type="button"  class="cancelbtn" ui-sref='home'>Cancel</button>
    </div>
  </div>
</form>
</div>
</div>
