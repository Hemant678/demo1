<!DOCTYPE html>
<html lang="en" ng-app="TestApp" ng-controller="testController">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/datatables.bootstrap.css">
<title>Data table</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>