<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct() {
        parent::__construct();
	    
    }
	public function index()
	{
		$this->load->view('includes/header');
		$this->load->view('main');
		$this->load->view('includes/footer');
	}

	public function product_list()
	{
 		$this->load->view('product_list');
	}

	public function edit_product()
	{
		$this->load->view('edit_product');
	}

	public function get_product_list() {
		$cond = array();
		$product_list = $this->Product_model->get_product_list($cond);
		echo json_encode($product_list); exit;
	}

	public function get_product_details() {
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		$product_id = $request->product_id;
		
		$cond = array("p_id" => $product_id);
		$product_details = $this->Product_model->get_product_details($cond);
		echo json_encode($product_details); exit;
	}

	public function edit_product_details() {
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		$product_id = $request->product_id;
		
		$cond = array("p_id" => $product_id);
		$updateArr = $this->Product_model->update(TB_PRODUCT,$cond,array("product_name" => $request->product_name,"product_quentity" => $request->product_quentity,"product_category"=>$request->product_category,"product_sub_category"=>$request->product_sub_category));
		echo '1'; die;
	}

}
