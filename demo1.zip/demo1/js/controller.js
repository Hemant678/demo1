app.controller('testController', ['$scope','$http','$state', function($scope,$http,$state){
		$scope.get_product_list = function() {
			$http({
					  method: 'GET',
					  url: base_url+'Home/get_product_list'
					}).then(function successCallback(response) {
						console.log(response.data);
					    $scope.productList = response.data;
					  }, function errorCallback(response) {
					  	console.log(response.data);
				});
			}

		  $scope.edit = function(product_id) {
		  	var params = {"product_id":product_id}
		  	var request = $http({
                method: "post",
                url: base_url+"Home/get_product_details",
                data:params,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            });
            request.success(function (response) {
                $scope.productDetails = response;
                $scope.p_id = response[0].p_id;
                $scope.productName = response[0].product_name;
                $scope.productQuentity = response[0].product_quentity;
                $scope.productCategory = response[0].product_category;
                $scope.productSubCategory = response[0].product_sub_category;
                $state.go('editproduct');
            });
        }


		$scope.update_product = function(p_id) {
			var params = {"product_id":p_id,product_name:$scope.productName,product_quentity:$scope.productQuentity,product_category:$scope.productCategory,product_sub_category:$scope.productSubCategory}
		  	console.log(params);
		  	return false;

		  	var request = $http({
                method: "post",
                url: base_url+"Home/edit_product_details",
                data:params,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            });
            request.success(function (response) {
                $state.go('home');
            });
		}

	}]);