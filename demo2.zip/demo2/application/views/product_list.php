
<style type="text/css">
	
.addfields{
    background: #00ff00;
    color: #FFF;
    font-weight: bold;
    font-size: 21px;
    border: 0;
    cursor: pointer;
    display: inline-block;
    padding: 4px 9px;
    vertical-align: top;
    line-height: 100%;   
}

.remove{
    background: #C76868;
    color: #FFF;
    font-weight: bold;
    font-size: 21px;
    border: 0;
    cursor: pointer;
    display: inline-block;
    padding: 4px 9px;
    vertical-align: top;
    line-height: 100%;   
}

</style>

<div class="container" style="min-height:500px;">
	<div class="container" style="padding:50px 50px;" ng-init="get_product_list()">


<button type="button" id="createIP" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Create IP</button>



<h1>IP List</h1>
<table class="table table-striped table-bordered" datatable="ng" dt-options="vm.dtOptions">
    <thead>
      <tr>
        <th>Sr</th>
        <th>IP Name</th>
        <th>IP Address</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr ng-repeat="ip in IpList">
        <td>{{$index + 1}}</td>
        <td>{{ip.ip_name}}</td>
        <td>{{ip.ip_address}}</td>
		<td><div class="btn-group">
        <button type="button" class="btn btn-default btn" data-toggle="modal" data-target="#myModal"><i class="glyphicon glyphicon-pencil"></i></button>
        </div></td>
      </tr>
    </tbody>
  </table>
</div>
</div>


<div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <input type="hidden" name="txt_master_ip" id="txt_master_ip" value="">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Create IP Address</h4>
          </div>
          <div class="modal-body">


              <div ng-controller="testController">

             <form name='frm_master_ip' novalidate="">

	  			<label  for="inlineFormInput">IP Name:</label>
	  			<input type="text" class="form-control" id="inlineFormInput" ng-model='ip_name' name="ip_name" required="">
	  			<span class="error pop_up ng-scope" ng-show="frm_master_ip.ip_name.$error.required" ng-if="frm_master_ip.ip_name.$dirty">Please enter your First name.</span>

  				<label for="inlineFormInputGroup">IP Address:</label>
  				<input type="text" class="form-control mb-1 mr-sm-2 mb-sm-0" id="inlineFormInputGroup" ng-model='ip_address'>

  				<div class="add_more" data-ng-repeat="ip in ips">
  				<label  for="inlineFormInput">Interface Name:</label>
	  			<input type="text" class="form-control mb-2 mr-sm-2 mb-sm-0" id="inlineFormInput" ng-model="ip.name" >
	  			
  				<label for="inlineFormInputGroup">Interface Address:</label>
  				<input type="text" class="form-control mb-2 mr-sm-2 mb-sm-0" id="inlineFormInputGroup" ng-model="ip.address">
  				<button class="addfields" ng-show="$last" ng-click="addNewChoice()">+</button>
      			<button class="remove" ng-show="$last" ng-click="removeChoice()">-</button>
  				</div>

  				<button type="submit" class="btn btn-primary" ng-click="add_master_ip()">Submit</button>
			</form>
   				
       
   
</div>
            
          </div>
          
        </div>

      </div>
    </div>
