<div class="container" style="min-height:500px;">
	<div class="container" style="padding:50px 50px;" ng-init="get_product_list()">
<h1>Product List</h1>
<table class="table table-striped table-bordered" datatable="ng" dt-options="vm.dtOptions">
    <thead>
      <tr>
        <th>Sr</th>
        <th>Product Name</th>
        <th>Product Quentity</th>
        <th>Product Category</th>
        <th>Product Sub Category</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr ng-repeat="product in productList">
        <td>{{$index + 1}}</td>
        <td>{{product.product_name}}</td>
        <td>{{product.product_quentity}}</td>
        <td>{{product.product_category}}</td>
        <td>{{product.product_sub_category}}</td>
		<td><div class="btn-group">
                <button type="button" class="btn btn-default btn" ng-click="edit(product.p_id);"><i class="glyphicon glyphicon-pencil"></i></button>  
                <button type="button" class="btn btn-default btn" ui-sref="editproduct"><i class="glyphicon glyphicon-trash"></i></button> 
                </div></td>
      </tr>
    </tbody>
  </table>
</div>
</div>
