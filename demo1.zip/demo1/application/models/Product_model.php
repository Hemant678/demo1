<?php
class Product_Model extends CI_Model{
    public $table;
    function __construct()
    {
        parent::__construct();
		$this->load->database();        
    }
    
    function insert($table,$data)
    {
		$this->db->protect_identifiers=true;
        $this->db->insert($table,$data);
       // echo $this->db->last_query();die;
        return $this->db->insert_id();
        
    }

    function update($table,$where=array(),$data)
    {
        $this->db->update($table,$data,$where);
        //echo $this->db->last_query();die;
        return $this->db->affected_rows();
    }
    
    function get_product_list($cond = array())
    {
        $this->db->select("p_id,product_name,product_quentity,product_category,product_sub_category", FALSE);
        $this->db->from(TB_PRODUCT);
        foreach ($cond AS $k => $v)
        {
            $this->db->where($k,$v);
        }
        $query = $this->db->get();
        return $query->result_array();
    }

    function get_product_details($cond = array()) {
        $this->db->select("p_id,product_name,product_quentity,product_category,product_sub_category", FALSE);
        $this->db->from(TB_PRODUCT);
        foreach ($cond AS $k => $v)
        {
            $this->db->where($k,$v);
        }
        $query = $this->db->get();
        return $query->result_array();
    }
    


    function select($sel,$table,$cond = false,$cond_or = false, $join = array(), $cond_like = array(),$order = false, $field = false)
	{
		$this->db->protect_identifiers=true;
		$this->db->select($sel, FALSE);
		$this->db->from($table);
                //$this->db->join('tbl_privilege', ''.$table.'.privilage_id=tbl_privilege.privilege_id', 'left');
        if($cond)
        {        
    		foreach ($cond AS $k => $v)
    		{
    			if($v !=""){
    				$this->db->where($k,$v);
    			}
    			else{
    				$this->db->where($k);
    			}
    		}
        }
        if($cond_or)
        {
    		foreach ($cond_or AS $k => $v)
    		{
                //echo $v;
    			if($v !=""){
    				$this->db->or_where($k,$v);
    			}
    			else{
    				$this->db->where($k);
    			}
    		
    		}
        }
        foreach ($join AS $k => $v)
		{
			$this->db->join($k,$v,'left');
		}
		foreach ($cond_like AS $k => $v)
		{
			$this->db->like($k,$v,'after');
		}
		if ($order && $field) {
            $this->db->order_by($field, $order);
        }
		$query = $this->db->get();
       // echo $this->db->last_query();die;
		return $query->result_array();
	}
}
?>

